import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Test class for Contact creation
public class ContactTest {

    // Test method for Contact creation
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("1234567890", "Timothy", "Davis", "1234567890", "123 Main St");

        // Assert that contact is not null
        assertNotNull(contact);

        // Assert that contact fields match the provided values
        assertEquals("1234567890", contact.getContactID());
        assertEquals("Timothy", contact.getFirstName());
        assertEquals("Davis", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }
}