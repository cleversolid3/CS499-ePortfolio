
import java.util.HashMap;
import java.util.Map;

// Class for managing contacts
class ContactService {
    private Map<String, Contact> contacts; // Map to store contacts

    // Constructor to initialize the contacts map
    public ContactService() {
        contacts = new HashMap<>();
    }

    // Method to add a contact to the map
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactID(), contact);
    }

    // Method to delete a contact from the map
    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }

    // Method to update a contact's first name
    public void updateFirstName(String contactID, String newFirstName) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.firstName = newFirstName;
        }
    }

    // Method to update a contact's last name
    public void updateLastName(String contactID, String newLastName) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.lastName = newLastName;
        }
    }

    // Method to update a contact's phone number
    public void updatePhone(String contactID, String newPhone) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.phone = newPhone;
        }
    }

    // Method to update a contact's address
    public void updateAddress(String contactID, String newAddress) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.address = newAddress;
        }
    }

    // Method to get a contact by its ID
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}