
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host='nv-desktop-services.apporto.com', port=32811, db='AAC', collection='animals'):
        try:
            self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}/')
            self.database = self.client[db]
            self.collection = self.database[collection]
        except ConnectionFailure:
            print("Failed to connect to MongoDB")

    def create(self, data):
        if data is not None:
            try:
                result = self.collection.insert_one(data)
                return True if result.inserted_id else False
            except Exception as e:
                print("Create error:", e)
                return False
        else:
            raise Exception("Nothing to save, data parameter is empty")

    def read(self, query):
        if query is not None:
            try:
                results = self.collection.find(query)
                return list(results)
            except Exception as e:
                print("Read error:", e)
                return []
        else:
            raise Exception("Nothing to read, query parameter is empty")

            
            
    def update(self, search_criteria, update_data):
        if search_criteria and update_data:
            try:
                result = self.collection.update_many(search_criteria, {"$set": update_data})
                return result.modified_count
            except Exception as e:
                print("Update error:", e)
                return 0
        else:
            raise Exception("Both search_criteria and update_data are required.")

    def delete(self, search_criteria):
        if search_criteria:
            try:
                result = self.collection.delete_many(search_criteria)
                return result.deleted_count
            except Exception as e:
                print("Delete error:", e)
                return 0
        else:
            raise Exception("search_criteria is required.")

