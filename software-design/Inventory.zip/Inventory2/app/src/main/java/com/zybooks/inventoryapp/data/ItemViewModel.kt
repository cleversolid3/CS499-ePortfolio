package com.zybooks.inventoryapp.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ItemViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = ItemRepository(AppDatabase.get(app).itemDao())

    private val _items = MutableStateFlow<List<Item>>(emptyList())
    val items: StateFlow<List<Item>> = _items

    fun refresh() = viewModelScope.launch {
        _items.value = repository.getAll()
    }

    fun insert(item: Item) = viewModelScope.launch {
        repository.insert(item)
        refresh()
    }

    fun delete(item: Item) = viewModelScope.launch {
        repository.delete(item)
        refresh()
    }

    // ⬇️ NEW
    fun update(item: Item) = viewModelScope.launch {
        repository.update(item)
        refresh()
    }
}
