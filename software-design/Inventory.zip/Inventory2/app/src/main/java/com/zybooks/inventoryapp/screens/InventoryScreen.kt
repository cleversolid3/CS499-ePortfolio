package com.zybooks.inventoryapp.screens

import android.Manifest
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zybooks.inventoryapp.data.Item
import com.zybooks.inventoryapp.data.ItemViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen() {
    val vm: ItemViewModel = viewModel()

    // Load items once when the screen appears
    LaunchedEffect(Unit) { vm.refresh() }

    // Observe DB items
    val items by vm.items.collectAsState()

    // Form + edit state
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var thr by remember { mutableStateOf("") }
    var editingId by remember { mutableStateOf<Long?>(null) }

    //  SMS permission + send helpers
    val ctx = LocalContext.current
    var pendingSms by remember { mutableStateOf<String?>(null) }

    val smsPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        pendingSms?.let { msg ->
            if (granted) {
                try {
                    // Replace with a real phone number when testing on a device
                    SmsManager.getDefault().sendTextMessage("5551234567", null, msg, null, null)
                    Toast.makeText(ctx, "SMS sent.", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, "SMS failed on this device/emulator.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(ctx, "SMS permission denied.", Toast.LENGTH_SHORT).show()
            }
        }
        pendingSms = null
    }

    fun sendSms(msg: String) {
        val granted = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) {
            try {
                // Replace with a real phone number when testing on a device
                SmsManager.getDefault().sendTextMessage("5551234567", null, msg, null, null)
                Toast.makeText(ctx, "SMS sent.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "SMS failed on this device/emulator.", Toast.LENGTH_SHORT).show()
            }
        } else {
            pendingSms = msg
            smsPermLauncher.launch(Manifest.permission.SEND_SMS)
        }
    }
    // ---------------------------------------------------

    Scaffold(
        topBar = { TopAppBar(title = { Text("Inventory") }) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val q = qty.toIntOrNull() ?: 0
                    val t = thr.toIntOrNull() ?: 0

                    if (editingId == null) {
                        vm.insert(Item(name = name.trim(), quantity = q, threshold = t))
                    } else {
                        vm.update(
                            Item(
                                id = editingId!!,
                                name = name.trim(),
                                quantity = q,
                                threshold = t
                            )
                        )
                    }

                    // reset form
                    name = ""; qty = ""; thr = ""; editingId = null
                }
            ) { Text(if (editingId == null) "+" else "✓") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {

            // ---- Input form ----
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Item name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = qty,
                onValueChange = { qty = it },
                label = { Text("Quantity") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = thr,
                onValueChange = { thr = it },
                label = { Text("Low-stock threshold") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))

            // ---- SMS buttons ----
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(onClick = { sendSms("Test alert from Inventory App") }) {
                    Text("Send Test Alert")
                }
                OutlinedButton(onClick = {
                    items.filter { it.quantity <= it.threshold }.forEach { low ->
                        sendSms("Low stock: ${low.name} (qty ${low.quantity})")
                    }
                }) {
                    Text("Send Low-Stock Alerts")
                }
            }

            Spacer(Modifier.height(8.dp))
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))

            // ---- Grid (Read, Edit, Delete) ----
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items) { item ->
                    Card {
                        Column(Modifier.padding(12.dp)) {
                            Text(item.name, style = MaterialTheme.typography.titleMedium)
                            Text("Qty: ${item.quantity}")
                            Text("Low at ≤ ${item.threshold}")
                            Spacer(Modifier.height(8.dp))
                            Row {
                                TextButton(onClick = { vm.delete(item) }) { Text("Delete") }
                                Spacer(Modifier.width(8.dp))
                                TextButton(onClick = {
                                    // Load into form for editing
                                    name = item.name
                                    qty = item.quantity.toString()
                                    thr = item.threshold.toString()
                                    editingId = item.id
                                }) { Text("Edit") }
                            }
                        }
                    }
                }
            }
        }
    }
}
