package com.zybooks.inventoryapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.zybooks.inventoryapp.screens.InventoryScreen
import com.zybooks.inventoryapp.ui.theme.InventoryTheme   // <-- if this is red, see note below

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Wrap UI with the app theme
            InventoryTheme {
                InventoryScreen()
            }
        }
    }
}
