package com.zybooks.inventoryapp.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

/**
 * CRUD operations for Item.
 */
@Dao
interface ItemDao {

    @Query("SELECT * FROM items ORDER BY name ASC")
    suspend fun getAll(): List<Item>

    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun getById(id: Long): Item?

    @Insert
    suspend fun insert(item: Item): Long

    @Update
    suspend fun update(item: Item): Int

    @Delete
    suspend fun delete(item: Item): Int

    @Query("DELETE FROM items")
    suspend fun clear()
}
