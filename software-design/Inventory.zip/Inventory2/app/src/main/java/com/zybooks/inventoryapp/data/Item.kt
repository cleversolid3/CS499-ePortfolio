package com.zybooks.inventoryapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Inventory item stored in Room.
 */
@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val quantity: Int,
    val threshold: Int,
    val updatedAt: Long = System.currentTimeMillis()
)

