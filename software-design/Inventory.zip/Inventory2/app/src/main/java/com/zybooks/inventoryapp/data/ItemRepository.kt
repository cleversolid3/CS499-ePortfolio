package com.zybooks.inventoryapp.data

class ItemRepository(private val dao: ItemDao) {

    suspend fun getAll(): List<Item> = dao.getAll()

    suspend fun insert(item: Item) = dao.insert(item)

    suspend fun delete(item: Item) = dao.delete(item)

    // ⬇️ NEW
    suspend fun update(item: Item) = dao.update(item)
}
